---
name: Goth Neon E-Commerce
colors:
  surface: '#13131b'
  surface-dim: '#13131b'
  surface-bright: '#393842'
  surface-container-lowest: '#0d0d16'
  surface-container-low: '#1b1b23'
  surface-container: '#1f1f27'
  surface-container-high: '#292932'
  surface-container-highest: '#34343d'
  on-surface: '#e4e1ed'
  on-surface-variant: '#e5bcc5'
  inverse-surface: '#e4e1ed'
  inverse-on-surface: '#302f39'
  outline: '#ac878f'
  outline-variant: '#5c3f46'
  surface-tint: '#ffb1c4'
  primary: '#ffb1c4'
  on-primary: '#65002e'
  primary-container: '#ff4a8d'
  on-primary-container: '#590028'
  inverse-primary: '#ba005b'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#cbc3da'
  on-tertiary: '#322e40'
  tertiary-container: '#948da3'
  on-tertiary-container: '#2b2739'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e1'
  primary-fixed-dim: '#ffb1c4'
  on-primary-fixed: '#3f001a'
  on-primary-fixed-variant: '#8f0044'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#e7dff7'
  tertiary-fixed-dim: '#cbc3da'
  on-tertiary-fixed: '#1d192a'
  on-tertiary-fixed-variant: '#494457'
  background: '#13131b'
  on-background: '#e4e1ed'
  surface-variant: '#34343d'
typography:
  display-lg:
    fontFamily: Syne
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Syne
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Syne
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Syne
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-contrast union between occult Victorian gothic romanticism and razor-sharp cyberpunk digitalism. Engineered specifically for a young, style-forward audience in urban Kazakhstan, the aesthetic rejects dated, gritty grunge in favor of a pristine, high-end "Cyber-Goth" editorial experience: deep midnight tones, dark glass surfaces, and laser-precise bioluminescent neon surges.

The interface evokes nocturnal allure, subversive luxury, and techno-mysticism. Core visual philosophies include:
- **Atmospheric Void:** Interfaces emerge out of true near-black fields, utilizing deep obsidian depths rather than muddy grays to give products total stage presence.
- **Controlled Luminescence:** Neon pink and cyan do not function as full flat fills; they act as concentrated currents—precise glowing rims, needle-thin borders, radioactive badges, and energetic micro-interactions.
- **Curated Darkness:** Layered translucent surfaces with satin-like frosted diffusion that separate interactive layers from infinite depth without visual noise.

## Colors

The palette is tuned strictly for an immersive dark-mode visual hierarchy. Primary surfaces stay rooted in abyssal obsidian, allowing glowing chromatic elements to project tangible depth and contrast.

### Palette Architecture
- **Canvas Base (`#0A0A12`):** Ultra-deep ink-violet black. Absorbs peripheral noise and anchors the dark atmospheric frame.
- **Surface Layer 1 (`#14121F`):** Recessed containers, sheet backdrops, and navigation underlays.
- **Surface Layer 2 (`#1F1B2C`):** Interactive card planes, modular sheets, input hulls, and floating dialogs.
- **Primary Accent (`#FF007F`):** Cyber magenta/neon pink. Drives transactional priorities: primary conversions, "Add to Cart", discount tags, and active heart/favorite states.
- **Secondary Accent (`#00F0FF`):** Glacial neon cyan. Serves as energetic contrast: filters, stock alerts, technical attributes, badges, and secondary highlights.
- **Glow & Border Tokens:**
  - `glow-pink`: `rgba(255, 0, 127, 0.35)` with spread for active states and critical calls to action.
  - `glow-cyan`: `rgba(0, 240, 255, 0.35)` for focus states and informational highlights.
  - `border-glass`: `rgba(255, 255, 255, 0.08)` for dormant separation.
- **Text & Editorial Hierarchy:**
  - **Text High-Emphasis (`#FFFFFF` & `#F1F1F7`):** Pure crystalline white for headlines, prices in KZT (`₸`), and key values.
  - **Text Mid-Emphasis (`#A5A1B8`):** Muted twilight lilac for descriptions, metadata, and placeholder copy.
  - **Text Disabled/Faint (`#5A5570`):** De-emphasized metadata, terms, and inactive icons.

## Typography

The typographic scale pairs **Syne**—an avant-garde, sculptural typeface with dramatic gothic poise and radical proportion—with **Inter**, a neutral, hyper-legible sans-serif tuned for complex Cyrillic alphabetic structures.

### Typography Guidelines
- **Headlines & Editorial Hooks (Syne):** Uses wide, severe glyph silhouettes to establish gothic drama. Headlines should remain concise, punchy, and letterspaced at `0` to `-0.02em` to preserve tight visual gravity.
- **Body & Data Layer (Inter):** High x-height, broad apertures, and impeccable Cyrillic rendering ensure flawless readability for Russian product titles, descriptions, sizing parameters, and reviews across high-density mobile displays.
- **Currency & Numbers:** Pricing numbers are set in bold Inter variants accompanied by the tenge symbol (`₸`), with deliberate kerning (`+0.01em`) to maintain prominent scanability in commerce feeds.

## Layout & Spacing

The layout is built upon an 8-point rhythmic grid, optimized around a 4-column mobile fluid layout with standard 16px (`1rem`) outer screen margins. 

### Rules & Responsive Behavior
- **Fluid Vertical Rhythm:** Spacing between stacked modules utilizes `space-lg` (24px) for distinct content blocks, while related items within product cards use `space-xs` (4px) and `space-sm` (8px).
- **Product Grids:** Staggered or balanced 2-column grids on mobile devices (`375px - 430px` viewports) utilize a 16px gutter (`gutter`), ensuring card tap targets remain generous and imagery is dominant.
- **Safe Area Insets:** Floating pill navigation and fixed bottom action bars ("Buy Now") enforce an additional 16px breathing clearance above hardware indicators (`safe-area-inset-bottom`).

## Elevation & Depth

Visual depth is achieved through **ambient neon diffusion** and **dark glassmorphism**, avoiding traditional light-based drop shadows that break down against dark fields.

### Elevation Hierarchy
- **Level 0 (Floor):** Canvas background `#0A0A12`.
- **Level 1 (In-flow Cards & Modules):** Surface `#1F1B2C` layered with a 1px perimeter border of `rgba(255, 255, 255, 0.06)` or `rgba(255, 0, 127, 0.15)`. No ambient shadow; visual separation relies on tonal difference and rim lighting.
- **Level 2 (Floating Cards & Modals):** Semi-transparent `#1F1B2C` at 85% opacity with `backdrop-filter: blur(16px)` and an ambient, atmospheric drop shadow: `0 8px 32px rgba(0, 0, 0, 0.6)`.
- **Level 3 (Neon Active Elevation):** Interactive focus, activated navigation indicators, and primary checkout buttons project an external bioluminescent radiance:
  - Magenta glow: `box-shadow: 0 0 20px rgba(255, 0, 127, 0.35), 0 0 2px rgba(255, 0, 127, 0.8)`.
  - Cyan glow: `box-shadow: 0 0 20px rgba(0, 240, 255, 0.35), 0 0 2px rgba(0, 240, 255, 0.8)`.

## Shapes

The design system uses soft, organic sweeps to balance the hard, aggressive color accents and gothic typography. The core roundedness is based on `0.5rem` (`8px`) as the base unit, stepping up to `1rem` (`16px`) for standard cards and `1.5rem` (`24px`, or `rounded-2xl`) for primary commerce tiles, sheets, and floating bars.

### Shape Applications
- **Base Components (Inputs, Chips, Small Buttons):** `8px` (`rounded`) to `16px` (`rounded-lg`).
- **Product & Content Containers:** `24px` (`rounded-2xl`) with clipped media bounds to give garments and decor items a polished, tactile feel.
- **Pill Elements (Tabs, Status Badges, Bottom Nav Container):** Fully rounded pill geometry (`9999px`) to emphasize fluidity against the nocturnal background.

## Components

### Buttons
- **Primary ("В корзину" / "Купить"):** High-impact neon pink (`#FF007F`) fill, dark text (`#0A0A12`, font weight 700), `rounded-full` or `rounded-2xl` height (52px). Radiates `glow-pink` under ambient illumination; scales to `0.98` on tap.
- **Secondary / Ghost:** Dark glass background (`rgba(31, 27, 44, 0.6)`), 1px neon cyan border (`rgba(0, 240, 255, 0.5)`), cyan text (`#00F0FF`).
- **Icon Actions (Wishlist Heart, Share):** Glass pill or circle surface (`#1F1B2C`), border `rgba(255, 255, 255, 0.1)`. Active state triggers neon pink fill with localized glow flash.

### Product Cards
- **Structure:** Dark surface container (`#1F1B2C`) with `rounded-2xl` (24px) corners and a 1px border `rgba(255, 0, 127, 0.2)`. 
- **Aspect Ratio & Imagery:** Tall portrait photography (`3:4`) styled with eerie atmospheric studio lighting.
- **Content Row:** Russian title in `Inter Body-MD` (`#FFFFFF`), category in twilight lilac (`#A5A1B8`), and price prominent in bold text with currency glyph: e.g., `45 000 ₸`.

### Badges & Chips
- **Neon Badges ("Новинка", "Эксклюзив", "-20%"):** Pill shape, dark translucent fill (`rgba(10, 10, 18, 0.8)`), 1px solid neon pink or cyan border, with neon-colored micro typography (`10px`, all-caps, tracking `+0.05em`).
- **Filter Chips:** Inactive: `#1F1B2C` background, `#A5A1B8` text, non-glowing. Active: `#FF007F` border, `rgba(255, 0, 127, 0.15)` tinted fill, crisp `#FFFFFF` text.

### Inputs & Search Bars
- **Surface:** Deep violet-black trough (`#14121F`), `rounded-xl` (16px), 50px height.
- **Border States:** Default border is `rgba(255, 255, 255, 0.08)`. Focus shifts to `1px solid #00F0FF` accompanied by subtle `glow-cyan` outer bloom.
- **Typography:** Placeholder text in `#A5A1B8`, active input in crystalline white (`#FFFFFF`).

### Checkboxes & Radio Buttons
- **Form:** 20px squares (checkbox) or circles (radio) with 1.5px borders in twilight lilac.
- **Checked State:** Neon pink fill with deep black checkmark/pip, casting a soft magenta aura on its immediate container.

### Bottom Navigation Bar
- **Architecture:** Floating dock suspended 16px above the display bottom edge, wrapped in frosted black glass (`rgba(15, 13, 23, 0.85)` with 20px backdrop blur).
- **Styling:** Pill geometry (`rounded-full`), hairline border in `rgba(0, 240, 255, 0.2)`.
- **Nav Items:** Inactive icons rendered in `#A5A1B8`. The active tab illuminates in `#00F0FF` with a micro neon dot indicator centered directly below the icon.